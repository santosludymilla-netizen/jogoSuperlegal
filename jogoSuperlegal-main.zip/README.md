# jogoSuperlegal

Jogo de sobrevivência de zumbis em 2D pixel art que roda no navegador, feito com Node.js.
Estética dark e macabra com contraste entre **verde neon** e **rosa neon**.

> Este README é o registro vivo do planejamento: toda ideia ou etapa nova é adicionada aqui.

**Status atual:** Parte 1 concluída — menu principal e base do projeto.

---

## Como rodar

```bash
npm install
npm start
```

Abre em [http://localhost:3000](http://localhost:3000).

Para desenvolvimento com recarga automática do servidor:

```bash
npm run dev
```

### Controles

| Ação | Comando |
|---|---|
| Navegar pelos botões | mouse ou teclado |
| Voltar do jogo (provisório) | `ESC` |

---

## Stack

- **Node.js + Express 5** — servidor de arquivos estáticos
- **HTML + CSS + JavaScript puro** — sem framework e sem etapa de build
- **Canvas 2D** — cenário do menu em resolução interna baixa, escalado com `image-rendering: pixelated`
- **DOM/CSS** — botões e textos do menu (acessíveis e fáceis de animar)
- **localStorage** — previsto para moedas e classes desbloqueadas
- **Fonte Press Start 2P** — self-hosted em `public/assets/fonts`

---

## Estrutura

```
jogoSuperlegal/
├── server.js                 # servidor Express
├── package.json
├── README.md
└── public/
    ├── index.html            # menu, overlay de sangue e tela provisória
    ├── css/style.css         # tema neon/macabro e botões
    ├── js/main.js            # cenário animado do menu + navegação
    └── assets/
        └── fonts/            # Press Start 2P (woff2)
```

---

## Identidade visual

| Uso | Cor |
|---|---|
| Fundo | `#050505` |
| Verde neon | `#39ff14` |
| Rosa neon | `#ff2e88` |
| Sangue | `#8b0000` |
| Osso / texto secundário | `#d8d8d0` |

Cenário do menu: lua de sangue, skyline com janelas acesas, zumbis silenciosos andando ao fundo, névoa verde/rosa, brasas subindo, scanlines, vinheta e sangue escorrendo do topo.
Menu: título com brilho e flicker; botão **JOGAR** centralizado, retangular, verde neon sobre preto; abaixo, botão menor **$ CLASSES** em rosa neon.

---

## Planejamento

### Parte 1 — Base + menu macabro ✅

- [x] `package.json` + `server.js` (Express, `npm start`)
- [x] `index.html` + `style.css` com o layout do menu
- [x] Cenário animado: lua de sangue, skyline, névoa, zumbis, brasas, vinheta e scanlines
- [x] Sangue escorrendo do topo da tela
- [x] Título **JOGO SUPERLEGAL** com glow verde e flicker
- [x] Botão **JOGAR** — centralizado, retangular, verde neon e preto
- [x] Botão **$ CLASSES** — menor, abaixo, rosa neon com símbolo de dinheiro
- [x] Hover, foco e clique com feedback visual
- [x] Navegação menu → tela provisória de jogo (`ESC` volta)

### Parte 2 — Núcleo da sobrevivência

- [ ] Player com movimento em 8 direções (WASD/setas)
- [ ] Arena com colisão
- [ ] Spawn de zumbis com IA de perseguição
- [ ] Vida, dano, invencibilidade curta e morte
- [ ] HUD com vida, onda e moedas

### Parte 3 — Combate

- [ ] Ataque corpo a corpo e/ou tiro com mira no mouse
- [ ] Morte de zumbi com sangue pixelado e partículas
- [ ] Drops de moeda
- [ ] Ondas progressivas com dificuldade crescente

### Parte 4 — Loja de classes

- [ ] Abrir loja pelo botão **$ CLASSES**
- [ ] Três classes iniciais com atributos diferentes
- [ ] Compra e desbloqueio permanente com moedas
- [ ] Seleção de classe antes da partida
- [ ] Save em `localStorage`

### Parte 5 — Polimento

- [ ] Áudio (tiros, dano, ambiente) via WebAudio
- [ ] Screen shake, flash de dano e sangue no chão
- [ ] Tela de game over com recorde
- [ ] Pause
- [ ] Ajustes finais de balanceamento

---

## Decisões técnicas

- Canvas com resolução interna de 1/4 do tamanho da tela: pixels grandes e nítidos em qualquer monitor.
- Cenário do menu desenhado por código com PRNG de semente fixa (mesma cidade a cada carregamento).
- Menu em DOM para ter botões reais (hover, foco, teclado) por cima do canvas.
- Sem bundler: ES modules nativos servidos pelo Express.
- Estado do jogo controlado por `running` + classes CSS; a máquina de estados completa (`MENU`, `PLAYING`, `SHOP`, `GAME_OVER`) entra junto com a Parte 2.
- Loop com `requestAnimationFrame` e delta time limitado a 50 ms.
