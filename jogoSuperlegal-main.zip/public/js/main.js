const canvas = document.getElementById('scene');
const ctx = canvas.getContext('2d');

const menu = document.getElementById('menu');
const game = document.getElementById('game');
const btnPlay = document.getElementById('btn-play');
const btnClasses = document.getElementById('btn-classes');

const PIXEL = 4;
const COLORS = {
  green: '#39ff14',
  pink: '#ff2e88',
  blood: '#8b0000',
  body: '#152815',
};

let W = 0;
let H = 0;
let horizon = 0;
let skyGradient = null;
let lastTime = 0;
let running = true;
let closeTimer = null;

let stars = [];
let backBuildings = [];
let frontBuildings = [];
let zombies = [];
let embers = [];

/* PRNG com semente fixa: o cenario nasce igual a cada carregamento */
function mulberry32(seed) {
  return function random() {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const ZOMBIE_SPRITE = [
  '..####..',
  '.######.',
  '.#e##e#.',
  '.######.',
  '..####..',
  '.#.##.#.',
  '#..##..#',
  '########',
  '..#..#..',
  '..#..#..',
  '.##..##.',
];

function makeWindows(width, height, random) {
  const windows = [];
  for (let y = 4; y < height - 4; y += 5) {
    for (let x = 3; x < width - 3; x += 4) {
      if (random() < 0.16) {
        windows.push({
          x,
          y,
          tint: random() < 0.7 ? COLORS.green : COLORS.pink,
        });
      }
    }
  }
  return windows;
}

function makeSkyline(depth, random) {
  const buildings = [];
  const maxHeight = H * (depth === 'back' ? 0.26 : 0.4);
  let x = -Math.floor(random() * 24);

  while (x < W) {
    const width = 9 + Math.floor(random() * (depth === 'back' ? 20 : 34));
    const height = Math.round(H * 0.07 + random() * maxHeight);
    buildings.push({
      x,
      width,
      height,
      windows: depth === 'front' ? makeWindows(width, height, random) : [],
    });
    x += width + 2 + Math.floor(random() * 12);
  }

  return buildings;
}

function buildScene() {
  const random = mulberry32(20261028);

  horizon = Math.round(H * 0.74);

  skyGradient = ctx.createLinearGradient(0, 0, 0, horizon);
  skyGradient.addColorStop(0, '#030304');
  skyGradient.addColorStop(0.45, '#08060a');
  skyGradient.addColorStop(0.82, '#140710');
  skyGradient.addColorStop(1, '#1b0810');

  const starCount = Math.round((W * H) / 900);
  stars = Array.from({ length: starCount }, () => ({
    x: Math.floor(random() * W),
    y: Math.floor(random() * horizon * 0.75),
    phase: random() * Math.PI * 2,
    tint: random() < 0.75 ? '#d8d8d0' : COLORS.green,
  }));

  backBuildings = makeSkyline('back', random);
  frontBuildings = makeSkyline('front', random);

  zombies = Array.from({ length: 5 }, () => ({
    x: random() * W,
    y: horizon + 3 + Math.floor(random() * 10),
    dir: random() < 0.5 ? -1 : 1,
    speed: 1.2 + random() * 2.6,
    phase: random() * Math.PI * 2,
  }));

  embers = Array.from({ length: 46 }, () => ({
    x: random() * W,
    y: random() * H,
    speed: 3 + random() * 10,
    drift: 2 + random() * 6,
    phase: random() * Math.PI * 2,
    tint: random() < 0.62 ? COLORS.green : COLORS.pink,
    alpha: 0.18 + random() * 0.5,
  }));
}

function resize() {
  W = Math.max(1, Math.ceil(window.innerWidth / PIXEL));
  H = Math.max(1, Math.ceil(window.innerHeight / PIXEL));
  canvas.width = W;
  canvas.height = H;
  buildScene();
}

function drawSky() {
  ctx.fillStyle = skyGradient;
  ctx.fillRect(0, 0, W, horizon);
}

function drawStars(time) {
  for (const star of stars) {
    ctx.globalAlpha = 0.25 + 0.45 * Math.abs(Math.sin(time * 0.9 + star.phase));
    ctx.fillStyle = star.tint;
    ctx.fillRect(star.x, star.y, 1, 1);
  }
  ctx.globalAlpha = 1;
}

function drawMoon() {
  const cx = Math.round(W * 0.79);
  const cy = Math.round(H * 0.2);
  const radius = Math.max(8, Math.round(H * 0.075));

  const halo = ctx.createRadialGradient(cx, cy, radius * 0.4, cx, cy, radius * 3.4);
  halo.addColorStop(0, 'rgba(255, 46, 136, 0.28)');
  halo.addColorStop(0.35, 'rgba(255, 46, 136, 0.1)');
  halo.addColorStop(1, 'rgba(255, 46, 136, 0)');
  ctx.fillStyle = halo;
  ctx.fillRect(cx - radius * 3.4, cy - radius * 3.4, radius * 6.8, radius * 6.8);

  ctx.beginPath();
  ctx.arc(cx, cy, radius, 0, Math.PI * 2);
  ctx.fillStyle = '#6b0b1a';
  ctx.fill();

  ctx.beginPath();
  ctx.arc(cx, cy, radius * 0.82, 0, Math.PI * 2);
  ctx.fillStyle = '#8f1024';
  ctx.fill();

  ctx.globalAlpha = 0.35;
  ctx.beginPath();
  ctx.arc(cx - radius * 0.22, cy - radius * 0.18, radius * 0.26, 0, Math.PI * 2);
  ctx.fillStyle = '#3d0510';
  ctx.fill();
  ctx.beginPath();
  ctx.arc(cx + radius * 0.28, cy + radius * 0.24, radius * 0.16, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;
}

function drawHorizonGlow() {
  const glow = ctx.createLinearGradient(0, horizon - H * 0.22, 0, horizon + 6);
  glow.addColorStop(0, 'rgba(255, 46, 136, 0)');
  glow.addColorStop(0.62, 'rgba(255, 46, 136, 0.07)');
  glow.addColorStop(0.9, 'rgba(255, 46, 136, 0.16)');
  glow.addColorStop(1, 'rgba(57, 255, 20, 0)');
  ctx.fillStyle = glow;
  ctx.fillRect(0, horizon - H * 0.22, W, H * 0.22 + 6);
}

function drawSkyline(buildings, color, windowAlpha) {
  for (const building of buildings) {
    const top = horizon - building.height;
    ctx.fillStyle = color;
    ctx.fillRect(building.x, top, building.width, building.height);

    if (building.windows.length) {
      ctx.globalAlpha = windowAlpha;
      for (const window of building.windows) {
        ctx.fillStyle = window.tint;
        ctx.fillRect(building.x + window.x, top + window.y, 1, 1);
      }
      ctx.globalAlpha = 1;
    }
  }
}

function drawGround() {
  ctx.fillStyle = '#050506';
  ctx.fillRect(0, horizon, W, H - horizon);

  ctx.globalAlpha = 0.06;
  ctx.fillStyle = COLORS.green;
  for (let y = horizon + 3; y < H; y += 4) {
    ctx.fillRect(0, y, W, 1);
  }
  ctx.globalAlpha = 1;
}

function drawFog(time) {
  for (let i = 0; i < 3; i += 1) {
    const cx = (((time * (0.012 + i * 0.006) + i * 0.41) % 1.5) - 0.25) * W;
    const cy = horizon - 8 + Math.sin(time * 0.45 + i * 1.7) * 5;
    const radius = W * 0.24;
    const tint = i === 1 ? '255, 46, 136' : '57, 255, 20';

    const fog = ctx.createRadialGradient(cx, cy, 0, cx, cy, radius);
    fog.addColorStop(0, `rgba(${tint}, 0.07)`);
    fog.addColorStop(1, `rgba(${tint}, 0)`);
    ctx.fillStyle = fog;
    ctx.fillRect(0, 0, W, H);
  }
}

function drawZombie(zombie, time) {
  const bob = Math.sin(time * 2.4 + zombie.phase);
  const step = Math.sin(time * 4.2 + zombie.phase) > 0 ? 0 : 1;
  const px = Math.round(zombie.x);
  const py = Math.round(zombie.y + bob);

  for (let row = 0; row < ZOMBIE_SPRITE.length; row += 1) {
    const line = ZOMBIE_SPRITE[row];

    for (let col = 0; col < line.length; col += 1) {
      const cell = line[col];
      if (cell === '.') continue;

      const x = px + (zombie.dir === 1 ? col : line.length - 1 - col);
      const y = py + row + (row > 7 && step ? 1 : 0);

      if (cell === 'e') {
        ctx.globalAlpha = 0.18;
        ctx.fillStyle = COLORS.green;
        ctx.fillRect(x - 1, y - 1, 3, 3);
        ctx.globalAlpha = 1;
        ctx.fillRect(x, y, 1, 1);
      } else {
        ctx.fillStyle = COLORS.body;
        ctx.fillRect(x, y, 1, 1);
      }
    }
  }
}

function drawZombies(time, delta) {
  for (const zombie of zombies) {
    zombie.x += zombie.dir * zombie.speed * delta;

    if (zombie.x > W + 12) zombie.x = -12;
    if (zombie.x < -12) zombie.x = W + 12;

    drawZombie(zombie, time);
  }
}

function drawEmbers(time, delta) {
  for (const ember of embers) {
    ember.y -= ember.speed * delta;
    if (ember.y < -4) {
      ember.y = H + 4;
      ember.x = Math.random() * W;
    }

    const x = ember.x + Math.sin(time * 1.4 + ember.phase) * ember.drift;
    ctx.globalAlpha = ember.alpha * (0.5 + 0.5 * Math.sin(time * 2 + ember.phase));
    ctx.fillStyle = ember.tint;
    ctx.fillRect(Math.round(x), Math.round(ember.y), 1, 1);
  }
  ctx.globalAlpha = 1;
}

function frame(now) {
  if (!running) return;

  const time = now * 0.001;
  const delta = lastTime ? Math.min(0.05, time - lastTime) : 0.016;
  lastTime = time;

  ctx.clearRect(0, 0, W, H);

  drawSky();
  drawStars(time);
  drawMoon();
  drawHorizonGlow();
  drawSkyline(backBuildings, '#07080a', 0);
  drawSkyline(frontBuildings, '#040405', 1);
  drawGround();
  drawFog(time + delta);
  drawZombies(time, delta);
  drawEmbers(time, delta);

  requestAnimationFrame(frame);
}

/* ---------- navegacao ---------- */

function openGame() {
  if (closeTimer) {
    clearTimeout(closeTimer);
    closeTimer = null;
  }

  menu.classList.add('is-hidden');
  game.hidden = false;
  requestAnimationFrame(() => game.classList.add('is-visible'));
  running = false;
}

function closeGame() {
  game.classList.remove('is-visible');
  menu.classList.remove('is-hidden');

  closeTimer = setTimeout(() => {
    game.hidden = true;
    running = true;
    lastTime = 0;
    requestAnimationFrame(frame);
    closeTimer = null;
  }, 400);
}

btnPlay.addEventListener('click', openGame);
btnClasses.addEventListener('click', () => {
  btnClasses.classList.remove('is-pressed');
  void btnClasses.offsetWidth;
  btnClasses.classList.add('is-pressed');
});

window.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && !game.hidden) closeGame();
});

game.addEventListener('click', closeGame);
window.addEventListener('resize', resize);

resize();
requestAnimationFrame(frame);
